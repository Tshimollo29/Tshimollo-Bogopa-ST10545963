package com.mycompany.quickchat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageIDLength() {
        Message msg = new Message("+27718693002", "Hi there", 1);
        System.out.println("Message ID: " + msg.getMessageID());
        assertEquals(10, msg.getMessageID().length(), "Message ID must be 10 chars");
        assertTrue(msg.checkMessageID(), "checkMessageID should be true");
    }

    @Test
    public void testRecipientCellSuccess() {
        Message msg = new Message("+27718693002", "Hello world", 0);
        String result = msg.checkRecipientCell();
        System.out.println("Recipient check: " + result);
        assertEquals("Cell phone number successfully captured", result);
    }

    @Test
    public void testRecipientCellFailure() {
        Message msg = new Message("08575975889", "Hello world", 0);
        String result = msg.checkRecipientCell();
        System.out.println("Recipient check fail: " + result);
        assertTrue(result.contains("incorrectly formatted"));
    }

    @Test
    public void testCreateMessageHash() {
        Message msg = new Message("+27718693002", "Hi Tonight", 1);
        String hash = msg.createMessageHash();
        System.out.println("Hash: " + hash);
        // Expected format: 00:0:HITONIGHT or 00:1:HITONIGHT
        assertTrue(hash.contains(":1:"));
        assertTrue(hash.endsWith("HITONIGHT"));
    }

    @Test
    public void testSentMessage() {
        Message msg1 = new Message("+27718693002", "Test 1", 0);
        assertEquals("Message successfully sent", msg1.SentMessage(1));

        Message msg2 = new Message("+27718693002", "Test 2", 0);
        assertEquals("Press 0 to delete the message", msg2.SentMessage(2));

        Message msg3 = new Message("+27718693002", "Test 3", 0);
        assertEquals("Message successfully stored", msg3.SentMessage(3));
    }

    @Test
    public void testReturnTotal() {
        Message.totalMessages = 0; // reset
        Message m1 = new Message("+27718693002", "Msg 1", 1);
        m1.SentMessage(1);
        Message m2 = new Message("+27718693002", "Msg 2", 2);
        m2.SentMessage(1);
        
        int total = m2.returnTotalMessagess();
        System.out.println("Total messages: " + total);
        assertEquals(2, total);
    }
    
    @Test
    public void testPrintMessages() {
        Message msg = new Message("+27718693002", "Hello world", 5);
        String output = msg.printMessages();
        System.out.println(output);
        assertTrue(output.contains("Message ID"));
        assertTrue(output.contains("+27718693002"));
        assertTrue(output.contains("Hello world"));
    }
}