package com.mycompany.quickchat;
import java.util.Scanner;

public class QuickChat {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Welcome to QuickChat.");

        System.out.print("How many messages do you wish to enter? ");
        int messageLimit = input.nextInt();
        input.nextLine();

        int messagesEntered = 0;

        
        while (true) {
            System.out.println("\nMenu:\n1) Send Messages\n2) Show recently sent messages\n3) Quit");
            System.out.print("Choose option: ");
            int menuChoice = input.nextInt();
            input.nextLine();

            
            switch (menuChoice) {
                case 1:
                    if (messagesEntered >= messageLimit) {
                        System.out.println("You have reached the limit of " + messageLimit + " messages.");
                        break;
                    }

                    System.out.print("Enter Recipient (with + e.g +27821234567): ");
                    String recipient = input.nextLine();

                    System.out.print("Enter Message (max 250 chars): ");
                    String text = input.nextLine();

                    if (text.length() > 250) {
                        System.out.println("Please enter a message of less than 250 characters.");
                        break;
                    } else {
                        System.out.println("Message sent");
                    }

                    Message msg = new Message(recipient, text, messagesEntered);

                    if (!msg.checkMessageID()) {
                        System.out.println("Message ID invalid");
                        break;
                    }
                    System.out.println(msg.checkRecipientCell());

                    System.out.println("Hash: " + msg.createMessageHash());

                    System.out.println("Choose: 1) Send Message 2) Disregard Message 3) Store Message to send later");
                    int sendChoice = input.nextInt();
                    input.nextLine();

                    String result = msg.SentMessage(sendChoice);
                    System.out.println(result);

                    if (sendChoice == 1) {
                        System.out.println("\n--- FULL MESSAGE DETAILS ---");
                        System.out.println(msg.printMessages());
                        messagesEntered++;
                    }

                    if (sendChoice == 2) {
                        System.out.print("Press 0 to confirm delete: ");
                        int del = input.nextInt();
                        input.nextLine();
                        if (del == 0) {
                            System.out.println("Message deleted");
                        }
                    }
                    break;

                case 2:
                    System.out.println("Coming Soon.");
                    break;

                case 3:
                    System.out.println("Total messages sent: " + Message.totalMessages);
                    System.out.println("Quitting...");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid option");
            }
        }
    }
}