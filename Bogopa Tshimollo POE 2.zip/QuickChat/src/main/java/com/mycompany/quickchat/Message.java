package com.mycompany.quickchat;

import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Message {
    private String messageID;
    private int numMessagesSent;
    private String recipient;
    private String message;
    private String messageHash;

    public static ArrayList<Message> sentMessages = new ArrayList<>();
    public static int totalMessages = 0;

    public Message(String recipient, String message, int num) {
        this.messageID = generateID();
        this.recipient = recipient;
        this.message = message;
        this.numMessagesSent = num;
        this.messageHash = createMessageHash();
    }

    private String generateID() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(id);
    }

    public boolean checkMessageID() {
        if (messageID.length() <= 10) {
            return true;
        } else {
            return false;
        }
    }

    public String checkRecipientCell() {
        if (recipient.length() <= 13 && recipient.startsWith("+")) {
            return "Cell phone number successfully captured";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code.";
        }
    }

    public String createMessageHash() {
        String[] words = message.split(" ");
        String first = words[0];
        String last = words[words.length - 1];
        String hash = messageID.substring(0, 2) + ":" + numMessagesSent + ":" + (first + last).toUpperCase();
        return hash;
    }

    public String SentMessage(int choice) {
        String output = "";
        switch (choice) {
            case 1:
                output = "Message successfully sent";
                sentMessages.add(this);
                totalMessages++;
                break;
            case 2:
                output = "Press 0 to delete the message";
                break;
            case 3:
                output = "Message successfully stored";
                storeMessage();
                break;
            default:
                output = "Invalid choice";
        }
        return output;
    }

    public String printMessages() {
        return "Message ID: " + messageID +
               "\nMessage Hash: " + messageHash +
               "\nRecipient: " + recipient +
               "\nMessage: " + message;
    }

    public int returnTotalMessagess() {
        return totalMessages;
    }
    public void storeMessage() {
        try (FileWriter file = new FileWriter("storedMessages.json", true)) {
            String json = "{\"MessageID\":\"" + messageID + "\",\"MessageHash\":\"" + messageHash +
             "\",\"Recipient\":\"" + recipient + "\",\"Message\":\"" + message + "\"}";
            file.write(json + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    public String getMessageHash() { return messageHash; }
    public String getMessageID() { return messageID; }
}